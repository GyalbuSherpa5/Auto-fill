from setuptools import setup, find_packages

setup(
    name="auto_fill",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        # Add dependencies here,
        # e.g. 'numpy>=1.11.1'
    ],
)
