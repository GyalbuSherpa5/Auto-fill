def suman():
    print("hi")