from .main import autofill
from .save_passwords import create_table, add_entry, retrieve_passwords, secret_key

create_table()
